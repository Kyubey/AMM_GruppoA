/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unica.pr2.libri;

/**
 *
 * @author studente
 */
public class LibroNonValidoException extends RuntimeException{
    public LibroNonValidoException(String msg){
        super(msg);
    }
    
}

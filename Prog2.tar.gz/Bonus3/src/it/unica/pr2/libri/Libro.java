/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unica.pr2.libri;

import java.util.Objects;

/**
 *
 * @author studente
 */
public class Libro implements Comparable<Libro>{


    private String nome;
    private int pagine;
    
    public Libro(String nome, int pagine){ 
        if(pagine <= 0) throw new LibroNonValidoException("Numero pagine negativo);");
        this.nome = nome;
        this.pagine = pagine;
    }
    
        public String getNome() {
        return nome;
    }

    public int getPagine() {
        return pagine;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPagine(int pagine) {
        this.pagine = pagine;
    }
@Override
public int compareTo(Libro o) {
   return pagine -o.pagine;
}

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 37 * hash + Objects.hashCode(this.nome);
        hash = 37 * hash + this.pagine;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Libro other = (Libro) obj;
        if (this.pagine != other.pagine) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        return true;
    }
    
    
}

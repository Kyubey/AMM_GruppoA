/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unica.pr2.libri;
import java.util.ArrayList;

/**
 *
 * @author studente
 */
public class Biblioteca extends ArrayList<Libro>{
    
    public Biblioteca(Libro[] libri){
        for(int i=0; i<libri.length; i++) add(libri[i]);
    
    }
    
    public int pagine(){
        int count =0;
        
        for(Libro l : this) count +=l.getPagine();
        
        return count;
    }
    
    @Override
    public String toString(){  
        if(size()==0) return "Nessun libro presente." ;
      
        
        String temp= "";
        for(Libro l : this){
            temp += l.getNome() + ": " + l.getPagine() + "; ";
        }
    temp = temp.substring(0, temp.length() -2);
    return temp + ".";
    }
}

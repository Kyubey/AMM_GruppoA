/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author studente
 */
    package it.unica.pr2.libri.test;
    import static org.junit.Assert.assertEquals;
    import static org.junit.Assert.fail;
    import static org.junit.Assert.assertTrue;
    import static org.junit.Assert.assertFalse;

    import org.junit.Test;
    import org.junit.Ignore;
    import org.junit.runner.RunWith;
    import org.junit.runners.JUnit4;
  

    import java.util.Collections;
    import java.util.List;
    import it.unica.pr2.libri.*; 	// tutte le classi richieste vanno messe qui.


@RunWith(JUnit4.class)
public class TestLibri {

	@Test
	public void test1() {
		// suggerimento: sfruttare ArrayList e l'ereditarieta' (utile nei prossimi test)
		Libro javabook = new Libro("Learn Java",150); 	// nome libro, pagine
		Libro cbook = new Libro("Tutto in C",120);		// nome libro, pagine
		Libro[] libri = new Libro[] {javabook, cbook}; 	// crea array di 2 elementi equivalente a libri[0] = javabook; libri[1] = cbook;

		Biblioteca bibliotecaInformatica = new Biblioteca(libri);
		assertTrue( bibliotecaInformatica.pagine() == 270 );

	}
	
	@Test
	public void test2() { 
		Libro javabook = new Libro("Learn Java",150);
		Libro cbook = new Libro("Tutto in C",120);
		Libro[] libri = new Libro[] {javabook, cbook};

		Biblioteca bibliotecaInformatica = new Biblioteca(libri);
		assertTrue( bibliotecaInformatica.pagine() == 270 );

		try {
			Libro x = new Libro("molto leggero",-5); 
			fail("Libro con pagine negative");
		}catch(LibroNonValidoException e) {
			// ok
		}
	}
	
	@Test
	public void test3() { 
		Libro javabook = new Libro("Learn Java",150);
		Libro cbook = new Libro("Tutto in C",120);
		Libro[] libri = new Libro[] {javabook, cbook};

		Biblioteca bibliotecaInformatica = new Biblioteca(libri);
		assertTrue( bibliotecaInformatica.pagine() == 270 );
	
		// suggerimento: avete sfruttato ArrayList e l'ereditarieta'??
		List libriInformatica = bibliotecaInformatica;
		assertTrue(libriInformatica.size() ==2);
		assertTrue(libriInformatica.get(0) == javabook);
		assertTrue(libriInformatica.get(1) == cbook);

	}

	@Test
	public void test4() { 
		Libro javabook = new Libro("Learn Java",150);
		Libro cbook = new Libro("Tutto in C",120);
		Libro[] libri = new Libro[] {javabook, cbook};

		Biblioteca bibliotecaInformatica = new Biblioteca(libri);
		assertTrue( bibliotecaInformatica.pagine() == 270 );

		// suggerimento: avete sfruttato ArrayList e l'ereditarieta'??
		List libriInformatica = bibliotecaInformatica;
		assertTrue(libriInformatica.size() == 2);

		// Ordina i libri in base al numero di pagine (dal piu' piccolo al piu' grande); funziona come Arrays.sort ma per le liste
		Collections.sort(libriInformatica);

		assertTrue(libriInformatica.get(0) == cbook);
		assertTrue(libriInformatica.get(1) == javabook);
	}

	@Test
	public void test5(){
		Libro javabook = new Libro("Learn Java",150);
		Libro cbook = new Libro("Tutto in C",120);
		Libro pr2book = new Libro("Programmazione in Java", 536);

		// Due Libri sono uguali se hanno stesso nome e numero di pagine 
		assertFalse(javabook.equals(pr2book));
		assertFalse(javabook.equals(new Libro("Learn Java",149)));
		assertTrue(javabook.equals(new Libro("Learn Java",150)));
	}

	@Test
	public void test6(){
		Libro javabook = new Libro("Learn Java",150);
		Libro cbook = new Libro("Tutto in C",120);
		Libro pr2book = new Libro("Programmazione in Java", 536);

		Biblioteca bibliotecaVuota = new Biblioteca(new Libro[0]);				// Nuova biblioteca senza libri.
		assertTrue(bibliotecaVuota.toString().equals("Nessun libro presente."));

		Libro[] libriC = new Libro[] {cbook};
		Biblioteca bibliotecaC = new Biblioteca(libriC);						// Biblioteca con un solo libro.
		assertTrue(bibliotecaC.toString().equals("Tutto in C: 120."));

		Libro[] libriInformatica = new Libro[] {javabook, cbook, pr2book};
		Biblioteca bibliotecaInformatica = new Biblioteca(libriInformatica);	// Biblioteca con n libri.
		assertTrue(bibliotecaInformatica.toString().equals("Learn Java: 150; Tutto in C: 120; Programmazione in Java: 536."));
	}
}
